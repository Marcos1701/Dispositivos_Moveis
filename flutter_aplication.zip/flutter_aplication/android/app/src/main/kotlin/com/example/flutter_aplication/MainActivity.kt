package com.example.flutter_aplication

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
