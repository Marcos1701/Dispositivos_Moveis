import 'package:flutter/material.dart';
import 'package:new_app/controller/mycontroller.dart';

void main() {
  runApp(const MyApp());
}